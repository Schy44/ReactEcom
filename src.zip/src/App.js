import logo from './logo.svg';
import './App.css';
import index from './pages/Main';
function App() {
  return (
    <div className="App">
      <index />
    </div>
  );
}

export default App;
