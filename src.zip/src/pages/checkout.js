import React, { Fragment } from "react";

function index() {
    return (
        <Fragment>
            checkout
        </Fragment>
    )
}

export default checkout;