import React, { Fragment } from "react";

function index() {
    return (
        <Fragment>
            product-details
        </Fragment>
    )
}

export default product - details;