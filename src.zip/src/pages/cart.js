import React, { Fragment } from "react";

function index() {
    return (
        <Fragment>
            cart
        </Fragment>
    )
}

export default cart;