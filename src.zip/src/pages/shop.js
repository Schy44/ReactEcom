import React, { Fragment } from "react";

function index() {
    return (
        <Fragment>
            shop
        </Fragment>
    )
}

export default shop;